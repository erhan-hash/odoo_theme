`1.2.0`
-------

- Add Dialog Module

`1.1.0`
-------

- Add Chatter Module

`1.0.0`
-------

- Initial Release
